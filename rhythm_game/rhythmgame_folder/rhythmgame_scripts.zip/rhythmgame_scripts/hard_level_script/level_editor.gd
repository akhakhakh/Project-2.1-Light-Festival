extends Node2D

# Modes
const in_edit_mode: bool = false

# The name of the current level being played
var current_level_name = "JINGLE_BELLS"

# Time (in seconds) it takes for a falling key to reach the hit line after spawning
var fk_fall_time: float = 3.0  # Faster fall time for 186 BPM

# Array to store recorded falling key timings when in edit mode
var fk_output_arr = [[], [], [], []]

# Level configuration data
var level_info = {
	"JINGLE_BELLS" : {
		# Music file for this level
		"music": load("res://rhythmgame_folder/rhythmgame_assets/music/fixedGlee Cast - Jingle Bells (Official Audio).wav")
	}
}

# Called when the scene starts
func _ready():
	if in_edit_mode:
		# If editing, load and play music manually for recording
		$MusicPlayer.stream = level_info.get(current_level_name).get("music")
		$MusicPlayer.play()
		# Connect key press signals to record timing
		Signals.KeyListenerPress.connect(KeyListenerPress)
	else:
		# In play mode, BeatManager_JingleBells handles music playback
		# Connect to the BeatManager_JingleBells autoload
		if has_node("/root/BeatManagerJingleBells"):
			var bm = get_node("/root/BeatManagerJingleBells")
			bm.connect("SpawnButton", Callable(self, "_on_spawn_button"))
			bm.StartMusic()
			print("BeatManager_JingleBells connected successfully!")
		else:
			print("ERROR: BeatManagerJingleBells not found! Check autoload settings.")
			print("Add BeatManager_JingleBells.cs as an autoload in Project Settings")

# Called when BeatManager wants to spawn a falling key - PLAY MODE
func _on_spawn_button(button_color: String) -> void:
	print("Spawn signal received for: ", button_color)
	# Convert color name to match KeyListener's expected format
	# BeatManager sends: "blue", "green", "red", "yellow"
	# KeyListener expects: "blue_button", "green_button", etc.
	var button_name = button_color + "_button"
	
	# Emit the signal to create the falling key
	Signals.CreateFallingKey.emit(button_name)

# Records key press time when in EDIT MODE
func KeyListenerPress(_button_name: String, array_num: int):
	#print(array_num)
	# Save the current playback time adjusted by the fall delay
	var spawn_time = $MusicPlayer.get_playback_position() - fk_fall_time
	fk_output_arr[array_num].append(spawn_time)
	
# Called when the music finishes playing
func _on_music_player_finished():
	print("Jingle Bells finished!")
	if in_edit_mode:
		print("Recorded timings: ", fk_output_arr)
